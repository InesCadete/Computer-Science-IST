/* iaed-23 - ist1102935 - project1 - MAIN file */

/*
 * Author: Ines Garcia Cortes Cadete
 * Student Number: 102935
 * Course: IAED (2023)
 *
 * Description:
    This program simulates a public transportation management system,
    allowing the user to add and list lines, their stops and possible links
    The commands implemmented are the following:
    | __q__ | quits the program |
    | __c__ | adds and lists the lines |
    | __p__ | adds and lists the stops |
    | __l__ | adds and lists the links between stops |
    | __i__ | lists the intersections between lines |
*/

#include <stdio.h>  
#include <stdlib.h> 
#include <ctype.h>  
#include <string.h> 

/* macros, structs and declarations file*/
#include "project1.h"
/******************************************************************************/
/* global variables */

Line arrayLines[MAX_LINES];
Stop arrayStops[MAX_STOPS];

int numLines = 0;
int numStops = 0;
/******************************************************************************/
/*                                C COMMAND                                   */
                                     
/* Function that lists all lines*/
void ListLines() {
    int i;

    for (i = 0; i < numLines; i++) {
        printf("%s", arrayLines[i].name);

        /* line has at least an originStop */
        if ((arrayLines[i].numStops) > 0) {
            printf(" %s ", arrayLines[i].originStop);
        }
        /* line has at least an originStop and a destStop */
        if ((arrayLines[i].numStops) >= 2) {
            printf("%s", arrayLines[i].destStop);
        }
        printf(" %d %0.2f %0.2f\n", arrayLines[i].numStops,
               arrayLines[i].totalCost, arrayLines[i].totalDuration);
    }
}

/* Function that checks if line exists. If yes -> returns its index */
int ExistLine(char lineName[]) {
    int i = 0;

    while (i <= numLines) {
        if (strcmp(arrayLines[i].name, lineName) == 0) {
            return i;
        }
        i++;
    }
    return FALSE;
}

/* Function that prints all the line's stops from origin to destination */
void ListLineStops(Line line) {
    int i;

    for (i = 0; i < line.numStops - 1; i++) {
        printf("%s, ", arrayStops[line.stopListIndex[i]].name);
    }
    printf("%s\n", arrayStops[line.stopListIndex[i]].name);
}

/* Function that prints all the line's stops from destination to origin */
void ListLineStopsInv(Line line) {
    int i;
    for (i = line.numStops - 1; i > 0; i--) {
        printf("%s, ", arrayStops[line.stopListIndex[i]].name);
    }

    printf("%s\n", arrayStops[line.stopListIndex[i]].name);
}

/*
 * Function called in MAIN
 * Description: adds and lists the lines.
 */
void AddListLines() {
    int numScanf;
    char c;
    int indexLine = 0;
    char input[BUFSIZ];
    char lineName[LINE_NAME + 1];
    char inv[MAX_INVERSO];
    Line line;
    
    /* no input after command */
    if ((c = getchar() == '\n')) {
        ListLines();
        return;
    }

    if (fgets(input, BUFSIZ, stdin) == 0) {return;}
    if ((numScanf = sscanf(input, " %s %s", lineName, inv)) == 0) {return;}    

    /* line already exists or is new*/
    if ((indexLine = ExistLine(lineName)) != FALSE){
        /* if input is only the line name -> lists its stops*/
        if (numScanf == 1) {
            if (arrayLines[indexLine].numStops == 0) {return;}
            else {
                ListLineStops(arrayLines[indexLine]);
            }
        }
        else if ((numScanf == 2) && 
            ((strcmp(inv, "inv") == 0) ||
            (strcmp(inv, "inve") == 0) ||
            (strcmp(inv, "inver") == 0) ||
            (strcmp(inv, "invers") == 0) ||
            (strcmp(inv, "inverso") == 0))) {
            ListLineStopsInv(arrayLines[indexLine]);
        }
        else {
            puts("incorrect sort option.");
        }
    }
    /* adds new line */
    else {
        if (numLines < MAX_LINES) {
            strcpy(line.name, lineName);
            arrayLines[numLines] = line;
            arrayLines[numLines].numStops = 0;
            arrayLines[numLines].totalCost = 0.0;
            arrayLines[numLines].totalDuration = 0.0;
            numLines++;
        }
    }
}
/******************************************************************************/
/*                                P COMMAND                                   */

/* Function that prints all the stops */
void ListStops() {
    int i = 0;

    for (i = 0; i < numStops; i++) {
        /*printar sem as aspas */
        printf("%s: %16.12f %16.12f %d\n", arrayStops[i].name, arrayStops[i].lat,
               arrayStops[i].longi, arrayStops[i].numLines);
    }
}

/* Function that prints lat and longi if stop exists. If not, an error message*/
void numScanf1(int stopIndex, char stopName[]) {

    if ((stopIndex = ExistStop(stopName)) != FALSE) {
            printf("%16.12f %16.12f\n", arrayStops[stopIndex].lat,
                   arrayStops[stopIndex].longi);
        }
        else {
            printf("%s: no such stop.\n", stopName);
        }
}

/* Function that prints and error message if stop already exists.
   If not, a new stop is created */
void numScanf3(char stopName[], Stop stop) {

    if (ExistStop(stopName) != FALSE) {
            printf("%s: stop already exists.\n", stopName);
        }
        else {
            /* creates a new stop */
            if (numStops < MAX_STOPS) {
                strcpy(stop.name, stopName);
                stop.numLines = 0;

                arrayStops[numStops] = stop;
                numStops++;
            }
        }

}

/* Function that checks if stop is in arrayStops. If yes -> returns its index */
int ExistStop(char stopName[]) {
    int i;

    for (i = 0; i < numStops; i++) {
        if (strcmp(arrayStops[i].name, stopName) == 0) {
            return i;
        }
    }
    return FALSE;
}

/*
 * Function called in MAIN
 * Description: adds and lists the stops
 */

void AddListStops(void) {
    char c;
    char stopName[STOP_NAME + 1];
    char input[BUFSIZ];
    int stopIndex;
    int numScanf = 0;
    Stop stop;

    if ((c = getchar()) == '\n') {
        ListStops();
        return;
    }

    if (fgets(input, BUFSIZ, stdin) == 0) {return;}

    /* reads with "" or without; saves it without the "" */
    if ((numScanf = sscanf(input, "\"%[^\"]\" %lf %lf",
        stopName, &stop.lat, &stop.longi)) == 0)
        numScanf = sscanf(input, "%s %lf %lf", stopName, &stop.lat, &stop.longi);    

    /* if the input was just the name of stop*/
    if (numScanf == 1) {
        numScanf1(stopIndex, stopName);
    }
    /* if lat and longi were also read in input */
    else if (numScanf == 3) {
        numScanf3(stopName, stop);
    }
}
/******************************************************************************/
/*                                L COMMAND                                   */

/* Function that reads and saves every character between quotes */
void ReadBetweenQuotes(char stopName[]) {
    char c;
    int i = 0;
    c = getchar();
    
    while (c != '\"') {
        stopName[i] = c;
        c = getchar();
        i++;
    }
    stopName[i] = '\0';
}

/* Function that reads and saves a word without quotes or spaces */
void ReadWithoutQuotes(char stopName[], char c) {
    int i = 0;

    while (c != ' ') {
            stopName[i] = c;
            c = getchar();
            i++;
    }
    stopName[i] = '\0';

}

/* Function that checks all errors of input in AddListLinks */
int NoErrors(double cost, double duration, int indexLine, int indexOriginStop, 
             int indexDestStop, char lineName[],
             char originStop[], char destStop[]) {

    if (cost < 0 || duration < 0) {
        puts("negative cost or duration.");
        return FALSE;
    }
    if (indexLine == FALSE) {
        printf("%s: no such line.\n", lineName);
        return FALSE;
    }
    if (indexOriginStop == FALSE) {
        printf("%s: no such stop.\n", originStop);
        return FALSE;
    }
    if (indexDestStop == FALSE) {
        printf("%s: no such stop.\n", destStop);
        return FALSE;
    }
    return TRUE;
}

/* Function that moves right all elements of array of stopIndexes of the line */
void ShiftRightArray(int newOriginStopIndex, int indexLine) {
    int i, temp;
    int insertNum = newOriginStopIndex;

    for (i = 0; i <= arrayLines[indexLine].numStops ; i++) {
        temp = arrayLines[indexLine].stopListIndex[i];
        arrayLines[indexLine].stopListIndex[i] = insertNum;
        insertNum = temp;
    }
}

/* Function that updates various fields of the line referenced */
void UpdateLine(int indexLine, double cost, double duration) {

        /* update originStop and DestStop */
        strcpy(arrayLines[indexLine].originStop, 
        arrayStops[arrayLines[indexLine].stopListIndex[0]].name);

        strcpy(arrayLines[indexLine].destStop, 
        arrayStops[arrayLines[indexLine].stopListIndex
        [arrayLines[indexLine].numStops - 1]].name);

        /* update the cost and duration */
        arrayLines[indexLine].totalCost += cost;
        arrayLines[indexLine].totalDuration += duration;
}

/* Function that chooses 1 of 4 ways to update the stopListIndex, 
   numStops of the line and numLines of the stops */
void ApplyWhichLink(int indexLine,  int indexOriginStop,
    int indexDestStop, int numStopsLine, double cost, double duration) {
    /* CASE 1: if there are no stops in line*/
    if (numStopsLine == 0) {
        /* originStop is the first stop and destStop is the last */
        arrayLines[indexLine].stopListIndex[0] = indexOriginStop;
        arrayLines[indexLine].stopListIndex[1] = indexDestStop;
        arrayLines[indexLine].numStops += 2;
        /* update the numLines of both stops*/
        arrayStops[indexOriginStop].numLines++;
        arrayStops[indexDestStop].numLines++;
        UpdateLine(indexLine, cost, duration);
    }

    /* CASE 2: if originStop is the last stop of the line
               and DestStop is the first stop of the line */
    else if ((arrayLines[indexLine].stopListIndex[numStopsLine - 1] 
    == indexOriginStop) &&
    (arrayLines[indexLine].stopListIndex[0] == indexDestStop)) {
        /* originStop is now the last stop as well as the first*/
        arrayLines[indexLine].stopListIndex[numStopsLine] = indexDestStop;
        arrayLines[indexLine].numStops++;
        /* update the numLines of originStop*/
        UpdateLine(indexLine, cost, duration);
    }

    /* CASE 3: if originStop is the last stop of the line */
    else if (arrayLines[indexLine].stopListIndex[numStopsLine - 1] 
    == indexOriginStop) {
        /* destStop is now the last stop */ 
        arrayLines[indexLine].stopListIndex[numStopsLine] = indexDestStop;
        arrayLines[indexLine].numStops++;
        /* update the numLines of destStop*/
        arrayStops[indexDestStop].numLines++;
        UpdateLine(indexLine, cost, duration);
    }
    
    /* CASE 4: if DestStop is the first stop of the line */
    else if (arrayLines[indexLine].stopListIndex[0] == indexDestStop) {
        /* insert new first stop at the start of stopIndexList*/
        ShiftRightArray(indexOriginStop, indexLine);
        arrayLines[indexLine].numStops++;
        /* update the numLines of originStop */
        arrayStops[indexOriginStop].numLines++;
        UpdateLine(indexLine, cost, duration);
    }
    else {
        puts("link cannot be associated with bus line.");
        return;
    }
}

/*
 * Function called in MAIN
 * Description: adds and lists the links between stops
 */
void AddListLinks() {
    int indexLine, indexDestStop, indexOriginStop, numStopsLine;
    int noError = TRUE;
    int firstWordQuotes = FALSE;
    char c;
    char lineName[LINE_NAME + 1];
    char originStop[STOP_NAME + 1];
    char destStop[STOP_NAME + 1];
    double cost, duration;

    if(scanf("%s", lineName) == 0) {return;};
   
    c = getchar();
    c = getchar();

    /* reads originStop with or without quotes */
    if (c == '\"') {
        ReadBetweenQuotes(originStop);
        firstWordQuotes = TRUE;
    }
    else {
        ReadWithoutQuotes(originStop, c);
    }
    c = getchar();
    if (firstWordQuotes == TRUE) {
        /* jump the space between originStop and destStop */
        c = getchar();
    }
    /* reads destStop with or without quotes */
    if (c == '\"') {
        ReadBetweenQuotes(destStop);
    }
    else {
        ReadWithoutQuotes(destStop, c);
    }

    if(scanf("%lf %lf", &cost, &duration) == 0) {return;};
    
    indexLine = ExistLine(lineName);
    indexOriginStop = ExistStop(originStop);
    indexDestStop = ExistStop(destStop);

    noError = NoErrors(cost, duration, indexLine, indexOriginStop, indexDestStop,
    lineName, originStop, destStop);

    if (noError == FALSE) {return;};

    numStopsLine = arrayLines[indexLine].numStops;
        
    ApplyWhichLink(indexLine,  indexOriginStop, indexDestStop, numStopsLine,
    cost, duration);
}

/******************************************************************************/
/*                                I COMMAND                                   */

/* Function that checks if stop is in line */
int StopIsInLine(int indexStop, int indexLine) {
    int i;

    for (i = 0; i < arrayLines[indexLine].numStops; i++) {
        if (arrayLines[indexLine].stopListIndex[i] == indexStop) {
            return TRUE;
        }
    }
    return FALSE;
} 

/* Adaption of InsertionSort algorithm to sort the lines' names in an array
   (alphabetically) */
void InsertSortArray(char array[MAX_LINES][LINE_NAME + 1], int len) {
    int i, j;
    char lineName[LINE_NAME + 1];

    for(i = 1; i < len; i++){
        strcpy(lineName, array[i]);
        j = i - 1;

        while(j >= 0 && strcmp(lineName, array[j]) < 0){
            strcpy(array[j + 1], array[j]);
            j = j - 1;
        }
        strcpy(array[j+1], lineName);
    }
}

/* Function that prints all the intersections */
void PrintIntersections(char stopName[], char array[MAX_LINES][LINE_NAME + 1],
 int len) {
    int i;

    printf("%s %d: ", stopName, len);

    for (i = 0; i < len - 1; i ++) {
        printf("%s ", array[i]);   
    }
    printf("%s\n", array[i]);
}

/*
 * Function called in MAIN
 * Description: lists the intersections between lines
 */
void Intersections() {
    int indexStop;
    int indexLine = 0;
    int len = 0;
    char lineName[LINE_NAME + 1];
    char tempArrayLineName[MAX_LINES][LINE_NAME + 1];

    for (indexStop = 0; indexStop < numStops; indexStop++) {
        len = 0;
        /* checks if stop is an intersection */
        if (arrayStops[indexStop].numLines >= 2) {

            for (indexLine = 0; indexLine < numLines; indexLine++) {

                if (StopIsInLine(indexStop, indexLine) == TRUE) {
                    /* saves the line name */
                    strcpy(lineName, arrayLines[indexLine].name);
                    /* inserts it in the array */
                    strcpy(tempArrayLineName[len], lineName);
                    
                    len++;
                }
            }
            InsertSortArray(tempArrayLineName, len);
            PrintIntersections(arrayStops[indexStop].name, 
            tempArrayLineName, len);
        }
    }
}
/******************************************************************************/
/*                                   MAIN                                     */
                                    
int main() {
    char command;

    command = getchar();

    while (command != 'q') {

        switch (command) {
        case 'c':
            AddListLines();
            break;
        case 'p':
            AddListStops();
            break;
        case 'l':
            AddListLinks();
            break;
        case 'i':
            Intersections();
            break;
        }
        command = getchar();
    }
    return 0;
}