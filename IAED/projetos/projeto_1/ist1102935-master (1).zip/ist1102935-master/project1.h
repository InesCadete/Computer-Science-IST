/* iaed-23 - ist1102935 - project1 - HEADER file */

/* 
 * Author: Ines Garcia Cortes Cadete
 * Student Number: 102935
 * Course: IAED (2023)
*/
#ifndef PROJECT1_H
#define PROJECT1_H

/* limiting constants */
#define MAX_LINES 200
#define MAX_STOPS 10000
#define MAX_LINKS 30000
#define LINE_NAME 20 
#define STOP_NAME 50
#define MAX_INVERSO 7

/* return constants for checking */
#define TRUE 1
#define FALSE -1

/******************************************************************************/
/* structs for Lines and Stops */
typedef struct {
	char name[LINE_NAME];
    char originStop[STOP_NAME];
	char destStop[STOP_NAME];
    int stopListIndex[MAX_STOPS];/*contains the indexes of stops in arrayStops*/
    int numStops;
    double totalCost;
    double totalDuration;
} Line;

typedef struct {
    char name[STOP_NAME];
    double lat;
    double longi;
    int numLines;
} Stop;

/******************************************************************************/
/* prototypes */

void ListLines(); 
int ExistLine(char lineName[]); 
void ListLineStops(Line line); 
void ListLineStopsInv(Line line); 
void AddListLines(); 
void ListStops(); 
void numScanf1(int stopIndex, char stopName[]); 
void numScanf3(char stopName[], Stop stop); 
int ExistStop(char stopName[]); 

void AddListStops(); 
void ReadBetweenQuotes(char stopName[]); 
void ReadWithoutQuotes(char stopName[], char c); 
int NoErrors(double cost, double duration, int indexLine, int indexOriginStop, 
             int indexDestStop, char lineName[],
             char originStop[], char destStop[]); 
void ShiftRightArray(int newOriginStopIndex, int indexLine); 
void UpdateLine(int indexLine, double cost, double duration); 
void ApplyWhichLink(int indexLine,  int indexOriginStop,
    int indexDestStop, int numStopsLine, double cost, double duration);
void AddListLinks(); 
int StopIsInLine(int indexStop, int indexLine); 
void InsertSortArray(char array[MAX_LINES][LINE_NAME + 1], int len); 
void PrintIntersections(char stopName[], char array[MAX_LINES][LINE_NAME + 1],
 int len); 
void Intersections(); 

#endif
