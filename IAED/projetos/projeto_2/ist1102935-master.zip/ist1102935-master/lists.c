 /* iaed-23 - ist1102935 - project2 */

/* LINKED LIST OPERATIONS */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

/* macros, structs and declarations file */
#include "project2.h"
/******************************************************************************/

/* Function that checks if there is enough memory.
    If there isn't,  it exits the program*/
void checkMemory(void *pointer) {
    if (pointer == NULL) {
        puts("No memory\n");
        exit(0);
    }
}

/* Function that duplicates a string, allocating space for it */
char *strdup(const char *src) {
    char *dst = malloc((strlen(src) + 1) * sizeof(char));
    checkMemory(dst);

    if (dst == NULL){
        return NULL;
    }
    strcpy(dst, src);
    return dst;
}

/******************************************************************************/

/* Function that checks if line exists. If yes, returns a pointer to it */
listItem *ExistItem(char *name, listItem **headP) {
    listItem *current = *headP;

    while (current != NULL){
    
        if (strcmp(name, current->name) == 0){
            return current;
        }
        current = current->next;
    }
    current = NULL;
    return current;
}

listItem *AllocListItem() {
    listItem *current = malloc(sizeof(listItem));
    checkMemory(current);
    return current;
}

line *AllocLine() {
    line *current = malloc(sizeof(line));
    checkMemory(current);
    return current;
}

/* Function that creates a new line, allocating memory */
listItem *CreateLine(char name[]) {
    listItem *new;
    line *line1;
    new = AllocListItem();
    line1 = AllocLine();

    new->name = strdup(name);
    new->content = line1;
    new->next = NULL;
    new->prev = NULL;
    ((line *)new->content)->head = NULL;
    ((line *)new->content)->tail = NULL;
    ((line *)new->content)->numStops = 0;
    ((line *)new->content)->totalCost = 0.0;
    ((line *)new->content)->totalDuration = 0.0;

    return new;
}

/* Function that adds the line when the linked list is empty */
void FirstItemEver(listItem *item, listItem **headP, listItem **tailP) {
    (*headP) = item;
    (*tailP) = item;
}

/* Function that adds an item to the first position of the linked list */
void AddFirst(listItem *item, listItem **headP) {
    item->next = (*headP);
    (*headP)->prev = item;
    (*headP) = item;
}

/* Function that adds an item to the last position of the linked list */
void AddLastItem(listItem *item, listItem **tailP) {
    (*tailP)->next = item;
    item->prev = (*tailP);
    (*tailP) = item;
}

/* Function that adds an item to a linked list */
void AddItem(listItem *item, listItem **headP, listItem **tailP, int first) {
    
    if (*headP == NULL) {
        FirstItemEver(item, headP, tailP);
    }
    else if(first == TRUE) {
        AddFirst(item, headP);
    }
    else {
        AddLastItem(item, tailP);
    }
}

/* Function that prints all the lines */
void ListLines(listItem **headLines) {
    listItem *head, *tail;
    listItem *current = *headLines;

    while (current != NULL) {
        head = ((line *)current->content)->head;
        tail = ((line *)current->content)->tail;

        printf("%s", current->name);

        /* line has at least an originStop */
        if (head != NULL) {
            printf(" %s ", ((listItem*)head->content)->name);
        }
        /* line has at least an originStop and a destStop */
        if (head != tail) {
            printf("%s", ((listItem*)tail->content)->name);
        }
        printf(" %d %0.2f %0.2f\n", ((line *)current->content)->numStops,
               ((line *)current->content)->totalCost,
               ((line *)current->content)->totalDuration);

        current = current->next;
    }
}

/* Function that prints all the line's stops from origin to destination */
void ListLineStops(listItem *line1, int notInv) {
    listItem *current;
    if (notInv == TRUE) {
        current = ((line *)line1->content)->head;
        
        while (current->next != NULL) {
            printf("%s, ", ((listItem*)current->content)->name);
            current = current->next;
        }        
        printf("%s\n", ((listItem*)current->content)->name);
    }
    else {
        current = ((line *)line1->content)->tail;
        while (current->next != NULL) {
            printf("%s, ", ((listItem*)current->content)->name);
            current = current->prev;
        }
        printf("%s\n", ((listItem*)current->content)->name);
    }
}

/*----------------------------------------------------------------------------*/
/* FUNCTIONS FOR CREATING AND ADDING STOPS */

stop *AllocStop() {
    stop *current = (stop *) malloc(sizeof(stop));
    checkMemory(current);
    return current;
}

/* Function that creates a new stop, allocating memory */
listItem *CreateStop(char *name, double lat, double longi) {
    listItem *new;
    stop *stop1;

    new = AllocListItem();
    stop1 = AllocStop();

    new->name = strdup(name);
    new->content = stop1;
    new->next = NULL;
    new->prev = NULL;
    ((stop *)new->content)->lat = lat;
    ((stop *)new->content)->longi = longi;
    ((stop *)new->content)->numLines = 0;
    ((stop *)new->content)->cost = 0.0;
    ((stop *)new->content)->duration = 0.0;

    return new;
}

/* Function that creates a node for the linked list of stops inside a line
   the node's contents are only the pointer to an already existing stop (stop1) */
listItem *CreateStopPointer(listItem *stop1) {
    listItem *new = AllocListItem();
   
    new->content = stop1;  
    new->name = NULL;
    new->prev = NULL;
    new->next = NULL;
    return new;
}

/* Function that creates and adds a node to
   the nested linked list of stops in the line */
void AddStopPointer(listItem *stop1, 
                    listItem **head, listItem **tail, int first) {
    listItem *stopToAdd = CreateStopPointer(stop1);
    
    AddItem(stopToAdd, head, tail, first);
    
}

/* function that prints all the stops */
void ListStops(listItem **headStops) {
    listItem *current = *headStops;

    while (current != NULL) {

        printf("%s: %16.12f %16.12f %d\n", current->name,
               ((stop *)current->content)->lat, ((stop *)current->content)->longi,
               ((stop *)current->content)->numLines);

        current = current->next;
    }
}

/****************************************************************************/
/* FUNCTIONS FOR UPDATING */

/* Function that updates the line's totalCost and totalDuration */
void UpdateLineCostDur(listItem *stop1, listItem *line1) {
    listItem *head = ((line *)line1->content)->head;
    listItem *tail = ((line *)line1->content)->tail;

    /* stop is the first stop */
    if(stop1 == head->content) {
        ((line *)line1->content)->totalCost -= 
        ((stop *)stop1->content)->cost;
        ((line *)line1->content)->totalDuration -= 
        ((stop *)stop1->content)->duration;       
    } 
    /* stop is the last stop */
    else if (stop1 == tail->content) {

        ((line *)line1->content)->totalCost -= 
        ((stop *)stop1->prev->content)->cost;
        ((line *)line1->content)->totalDuration -= 
        ((stop *)stop1->prev->content)->duration;   

        ((stop *)(stop1->prev)->content)->cost = 0.0;
        ((stop *)(stop1->prev)->content)->duration = 0.0;
    }
    /* stop is somewhere in the middle */
    else {

        ((line *)line1->content)->totalCost -= 
        ((stop *)stop1->content)->cost;
        ((line *)line1->content)->totalDuration -= 
        ((stop *)stop1->content)->duration;     

        ((line *)stop1->prev->content)->totalCost = 
        ((stop *)stop1->content)->cost;
        ((line *)stop1->prev->content)->totalDuration = 
        ((stop *)stop1->content)->duration;     
    }
}

/* Function that resets the totalCost and totalDuration of the line to 0 */
void ResetLineCostDurNumStops(listItem *line1) {
    ((line *)line1->content)->totalCost = 0.0;
    ((line *)line1->content)->totalDuration = 0.0;
    ((line *)line1->content)->numStops = 0;
}

/* Function that updates the totalCost and totalDuration fields in the line */
void UpdateLine(listItem *line1, double cost, double duration) {
    ((line*) line1->content)->totalCost += cost;
    ((line*) line1->content)->totalDuration += duration;
}

/* Function that saves the cost and duration of the link in originStop */
void UpdateOriginStop(listItem *originStop, double cost, double duration) {
    ((stop *)originStop->content)->cost = cost;
    ((stop *)originStop->content)->duration = duration;
}
/******************************************************************************/
/* FUNCTIONS FOR EXTRACTING AND DELETING ITEMS, etc */

/* Function that deletes a whole linked list */
void EmptyList(listItem **head) {
    listItem *current = *head;
    /* listItem *next; */


    while (current != NULL) {
        ExtractItem(head, current);
        current = current->next;
    }   
}

/* Function that extracts an item from a double linked list */
listItem *ExtractItem(listItem **head, listItem *item) {
    /* the item is the head of the list*/

    if (*head == item) {
        *head = item->next;
    }
    /* the item is not the head nor the tail*/
    else if (item->next != NULL) {
        item->next->prev = item->prev;
        item->prev->next = item->next;
    }
    /* the item is the tail */
    else if (item->prev != NULL) {
        item->prev->next = item->next;
    }
    return item;
}

/* Function that checks if the stop is in the line */
listItem *StopIsInLine(listItem *stop1, listItem *line1) {
    listItem *current = ((line *)line1->content)->head;

    while (current != NULL) {
        if (current->content == stop1){
            return current;
        }
        current = current->next;
    }
    return NULL;
}

/* Function that goes through all the stops
and reduces the numLines of the ones that are in the line  */
void ReduceNumLines(listItem *line1, listItem **headStops) {
    listItem *current;

    /* go through all the stops and update the ones in the line */
    for (current = *headStops; current != NULL; current = current->next) {

        if (StopIsInLine(current, line1) != NULL) {
            ((stop *)current->content)->numLines--;
        }
    }
}

/* Funtion that frees all memory allocated for a ListItem */
void FreeListItem(listItem *item) {

    if(item->name != NULL) {
    free(item->name);
    }
    if(item->content != NULL) {
        free(item->content);
    }
    free(item);  
}

