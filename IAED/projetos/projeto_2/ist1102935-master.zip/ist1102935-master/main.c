/* iaed-23 - ist1102935 - project2  */

/*
 * Author: Ines Garcia Cortes Cadete
 * Student Number: 102935
 * Course: IAED (2023)
 *
 * Description:
    This program simulates a public transportation management system,
    allowing the user to add and list lines, their stops and possible links
    The commands implemmented are the following:
    | __q__ | quits the program |
    | __c__ | adds and lists the lines |
    | __p__ | adds and lists the stops |
    | __l__ | adds and lists the links between stops |
    | __i__ | lists the intersections between lines |
    | __r__ | remove uma carreira |
    | __e__ | elimina uma paragem |
    | __a__ | apaga todos os dados |    
*/

#include <stdio.h>  
#include <stdlib.h> 
#include <ctype.h>  
#include <string.h> 

/* macros, structs and declarations file */
#include "project2.h"
/******************************************************************************/
/*                                C COMMAND                                   */
      
/*
 * Function called in MAIN
 * Description: adds and lists the lines.
 */
void AddListLines(listItem **headLines, listItem **tailLines) {
    char c, input[MAX_INPUT];
    char tempName[MAX_INPUT], inv[MAX_INPUT];
    int numScanf = 0;
    listItem *current;

    /* no input after command */
    if ((c = getchar() == '\n')) {
        ListLines(headLines);
        return;
    }

    if (fgets(input, MAX_INPUT, stdin) == 0) {return;}
    if ((numScanf = sscanf(input, " %s %s", tempName, inv)) == 0) {return;}    
    
    current = ExistItem(tempName, headLines);

    /* line already exists or is new*/
    if (current != NULL){
        /* if input is only a line name -> lists its stops*/
        if (numScanf == 1) {
            if (((line *) current->content)->numStops == 0) {return;}
            else {
                ListLineStops(current, TRUE);
            }
        }
        else if ((numScanf == 2) && 
            ((strcmp(inv, "inv") == 0) ||
            (strcmp(inv, "inve") == 0) ||
            (strcmp(inv, "inver") == 0) ||
            (strcmp(inv, "invers") == 0) ||
            (strcmp(inv, "inverso") == 0))) {
            ListLineStops(current, FALSE);
        }
        else {
            puts("incorrect sort option.");
        }
    }
    /* adds new line */
    else {
        AddItem(CreateLine(tempName), headLines, tailLines, FALSE);
    }
}

/******************************************************************************/
/*                                P COMMAND                                   */
/*
 * Function called in MAIN
 * Description: adds and lists the stops
 */
void AddListStops(listItem **headStops, listItem **tailStops){
    char c;
    char tempName[MAX_INPUT], input[MAX_INPUT];
    double lat, longi;
    int numScanf = 0;
    listItem *current;

    if ((c = getchar()) == '\n') {
        ListStops(headStops);
        return;
    }

    if (fgets(input, MAX_INPUT, stdin) == 0) {return;}

    /* reads with "" or without; saves it without the "" */
    if ((numScanf = sscanf(input, "\"%[^\"]\" %lf %lf",
        tempName, &lat, &longi)) == 0)
        numScanf = sscanf(input, "%s %lf %lf", tempName, &lat, &longi);    
    
    current = ExistItem(tempName, headStops);
    /* if the input was just the name of stop*/
    if (numScanf == 1) {
        if (current != NULL) {
            printf("%16.12f %16.12f\n", ((stop *)current->content)->lat,
             ((stop *)current->content)->longi);
        }
        else {
            printf("%s: no such stop.\n", tempName);
        }
    }
    /* if lat and longi were also read in input */
    else if (numScanf == 3) {
        if (current != NULL) {
            printf("%s: stop already exists.\n", tempName);
        }
        else {
            /* creates a new stop */
            AddItem(CreateStop(tempName, lat, longi),
            headStops, tailStops, FALSE);
        }
    }
}

/******************************************************************************/
/*                                L COMMAND                                   */

/* Function that reads and saves every character between quotes */
void ReadBetweenQuotes(char stopName[]) {
    char c;
    int i = 0;
    c = getchar();
    
    while (c != '\"') {
        stopName[i] = c;
        c = getchar();
        i++;
    }
    stopName[i] = '\0';
}

/* Function that reads and saves a word without quotes or spaces */
void ReadWithoutQuotes(char stopName[], char c) {
    int i = 0;

    while (c != ' ') {
            stopName[i] = c;
            c = getchar();
            i++;
    }
    stopName[i] = '\0';
}

/* Function that checks all errors of input in AddListLinks */
int NoErrors(double cost, double duration, listItem *line1,
             listItem *originStop, listItem *destStop, 
             char lineName[], char originStop1[], char destStop1[]){ 

    if (cost < 0 || duration < 0) {
        puts("negative cost or duration.");
        return FALSE;
    }
    if (line1 == NULL) {
        printf("%s: no such line.\n", lineName);
        return FALSE;
    }
    if (originStop == NULL) {
        printf("%s: no such stop.\n", originStop1);
        return FALSE;
    }
    if (destStop == NULL) {
        printf("%s: no such stop.\n", destStop1);
        return FALSE;
    }
    return TRUE;
}

/* Function that chooses 1 of 4 ways to update the nested linked list of stops
in a line, updating the line as well */
void ApplyWhichLink(listItem *line1,
                    listItem *originStop, listItem *destStop, 
                    double cost, double duration) {

    listItem **head = &(((line*)line1->content)->head);
    listItem **tail = &(((line*)line1->content)->tail);

   /* CASE 1: if there are no stops in line*/
    if (*head == NULL) {
        AddStopPointer(originStop, head, tail, FALSE);
        AddStopPointer(destStop, head, tail, FALSE);

        /* update the line*/
        ((line*) line1->content)->numStops += 2;
        /* update the numLines of the stops */
        if (originStop != destStop) {
            ((stop*)originStop->content)->numLines++;
            ((stop*)destStop->content)->numLines++;
        }
        else {
            ((stop*)originStop->content)->numLines++;
        }
        
        /* saves the cost and duration in originStop */
        UpdateOriginStop(originStop, cost, duration);
    }
    /* CASE 2: if originStop is the last stop of the line
               and DestStop is the first stop of the line */
    else if ((originStop == (*tail)->content) && (destStop == (*head)->content)) {
        /* insert the first stop at the end (circular line) */
        AddStopPointer(destStop, head, tail, FALSE);
        ((line*) line1->content)->numStops++;

        UpdateOriginStop(originStop, cost, duration);
    }
    /* CASE 3: if originStop is the last stop of the line */
    else if (originStop == (*tail)->content) {
        /* insert the new last stop */
        AddStopPointer(destStop, head, tail, FALSE);
        ((line*) line1->content)->numStops++;
        ((stop*)destStop->content)->numLines++;

        UpdateOriginStop(originStop, cost, duration);
    }
    /* CASE 4: if DestStop is the first stop of the line */
    else if (destStop == (*head)->content) {
        /* insert new first stop at the start of the list*/
        AddStopPointer(originStop, head, tail, TRUE);
        ((line*) line1->content)->numStops++;
        ((stop*)originStop->content)->numLines++;

        UpdateOriginStop(originStop, cost, duration);
    }
    else {
        puts("link cannot be associated with bus line.");
        return;
    }
    UpdateLine(line1, cost, duration);
}

/*
 * Function called in MAIN
 * Description: adds and lists the links between stops
 */
void AddListLinks(listItem **headLines, listItem **headStops) {
    int noError = TRUE;
    int firstWordQuotes = FALSE;
    char c;
    char lineName[MAX_INPUT];
    char originStop[MAX_INPUT];
    char destStop[MAX_INPUT];
    double cost, duration;
    listItem *line1, *originStop1, *destStop1;
    /* listItem **head, **tail; 
    listItem *current; */

    if(scanf("%s", lineName) == 0) {return;};
   
    c = getchar();
    c = getchar();

    /* reads originStop with or without quotes */
    if (c == '\"') {
        ReadBetweenQuotes(originStop);
        firstWordQuotes = TRUE;
    }
    else {
        ReadWithoutQuotes(originStop, c);
    }
    c = getchar();
    if (firstWordQuotes == TRUE) {
        /* jump the space between originStop and destStop */
        c = getchar();
    }
    /* reads destStop with or without quotes */
    if (c == '\"') {
        ReadBetweenQuotes(destStop);
    }
    else {
        ReadWithoutQuotes(destStop, c);
    }

    if(scanf("%lf %lf", &cost, &duration) == 0) {return;};
    
    line1 = ExistItem(lineName, headLines);

    originStop1 = ExistItem(originStop, headStops);
    destStop1 = ExistItem(destStop, headStops);

    noError = NoErrors(cost, duration, line1, originStop1, destStop1,
    lineName, originStop, destStop);

    if (noError == FALSE) {return;}

    ApplyWhichLink(line1, originStop1, destStop1, cost, duration);
}

/******************************************************************************/
/*                                I COMMAND                                   */

/* Adaption of InsertionSort algorithm to sort the lines' names in an array
   (alphabetically) */
void InsertSortArray(char **array, int len) {
    int i, j;
    char *temp;

    for(i = 1; i < len; i++){
        temp = array[i];
        j = i - 1;

        while(j >= 0 && 
             strcmp(temp, array[j]) < 0){
            
            array[j + 1] = array[j];

            j = j - 1;
        }
        array[j+1] = temp;
    }
}

/* Function that prints all the intersections */
void PrintIntersections(char *name, char **array, int len) {
    int i;

    printf("%s %d: ", name, len);

    for(i = 0; i < len - 1; i ++) {
        printf("%s ", array[i]);   
    }
    printf("%s\n", array[i]);
}

/*
 * Function called in MAIN
 * Description: lists the intersections between lines
 */
void Intersections(listItem **headStops, listItem **headLines) {
    char **namePointArray = NULL;
    listItem *currentStop = *headStops; 
    listItem *currentLine = *headLines;
    int i = 0;
    int numLines = 0; 

    while(currentStop != NULL) {
        numLines = ((stop*)(currentStop -> content))->numLines;
        if(numLines >= 2) {
            currentLine = *headLines;
            
            namePointArray = (char **)malloc(numLines *sizeof(char *));
            checkMemory(namePointArray);
            i = 0;

            while(currentLine != NULL && i < numLines) {

                if(StopIsInLine(currentStop, currentLine) != NULL) {
                    /* fill nameArray */
                    namePointArray[i] = currentLine->name;                    
                    i++;
                }                 
                currentLine = currentLine->next;
            }
            if(i >= 2) {
                InsertSortArray(namePointArray, numLines);   
                PrintIntersections(currentStop->name, namePointArray, numLines);
            }
        }
        /* if memory was allocated for the array, frees it */
        currentStop = currentStop->next;
    }
    if(namePointArray != NULL) {
        
        free(namePointArray);
    }
}

/******************************************************************************/
/*                                R COMMAND                                   */

/*
 * Function called in MAIN
 * Description: Removes a Line
 */
void RemoveLine(listItem **headLines, listItem **headStops) {
    char input[BUFSIZ], name[BUFSIZ];
    listItem *line1;

    if(fgets(input, BUFSIZ, stdin) == 0) {return;}
    if((sscanf(input, "%s", name)) == 0) {return;}  

    line1 = ExistItem(name, headLines);

    if(line1 == NULL) {
        printf("%s: no such line.\n", name);
        return;
    }
    /* extract and delete all of the line's stops */
    if((((line *)line1->content)->numStops) > 0) {
        ReduceNumLines(line1, headStops);
        EmptyList(&((line *)line1->content)->head);
    }
    ExtractItem(headLines, line1);
    FreeListItem(line1);
}

/******************************************************************************/
/*                                E COMMAND                                   */

/*
 * Function called in MAIN
 * Description: Eliminates a Stop
 */
void EliminateStop(listItem **headStops, listItem **headLines) {
    listItem *stop1, *next;
    listItem *currentLine, *currentStop; 
    listItem *head;
    char input[BUFSIZ], tempName[BUFSIZ];
    
    if(fgets(input, BUFSIZ, stdin) == 0) {return;}
    if((sscanf(input, "%s", tempName)) == 0) {return;}  

    stop1 = ExistItem(tempName, headStops);

    if(stop1 == NULL) {
        printf("%s: no such stop.\n", tempName);
        return;
    }
    /* Remove the stop from the linked lists in the lines its in */
    if(((stop*)stop1->content)->numLines > 0) {
        for(currentLine = *headLines; currentLine != NULL;
        currentLine = currentLine->next) {

            head = (((line *)currentLine->content)->head);

            if(StopIsInLine(stop1, currentLine) != NULL) {

                if(((line*)currentLine->content)->numStops == 2) {
                    
                    EmptyList(&head);
                    ResetLineCostDurNumStops(currentLine);
                    ((stop*)stop1->content)->numLines--;
                    return;
                } 
                else {
                    /* delete every occurence of the stop in the line */
                    currentStop = head;
                    while(currentStop != NULL) {
                        next = currentStop->next;

                        if(currentStop->content == stop1) {
                            UpdateLineCostDur(currentStop->content, currentLine);
                            ExtractItem(&head, currentStop);
                            
                            (((line *)currentLine->content)->head) = head;
                            
                            ((line*)currentLine->content)->numStops--;
                            ((stop*)stop1->content)->numLines--;
                        }
                        currentStop = next;
                    }
                }            
            }
        }
    }
    /* remove the stop from the linked list of all stops */
    currentStop = *headStops;
    while(currentStop != NULL) {
        next = currentStop->next;
        if(currentStop == stop1) {
            ExtractItem(headStops, currentStop);
            FreeListItem(currentStop);
        }
        currentStop = next;
    }          
}

/******************************************************************************/
/*                                A COMMAND                                   */

/*
 * Function called in MAIN
 * Description: frees all memory
 */

void FreeMemory(listItem **headLines, listItem **headStops) {
    listItem *currentStop, *currentLine;
    listItem *next;


    /* frees the lines */
    currentLine = *headLines;
    if(currentLine != NULL) {
        /* if there is only one line */
        if (currentLine->next == NULL) {

            if(((line*)currentLine->content)->numStops > 0) {
                EmptyList(&((line *)currentLine->content)->head);
            }
            FreeListItem(currentLine);
        }
        else {
            while(currentLine->next != NULL) {
                next = currentLine->next;

                if(((line*)currentLine->content)->numStops > 0) {
                    EmptyList(&((line *)currentLine->content)->head);
                }
                FreeListItem(currentLine);
                currentLine = next;
        }
        FreeListItem(currentLine);  
        }
    }

    /* frees the stops */
    currentStop = *headStops;
    if(currentStop != NULL) {

         while(currentStop->next != NULL) {
            next = currentStop->next;

            FreeListItem(currentStop);
            currentStop = next;
        }
        FreeListItem(currentStop);

    }    
}

/******************************************************************************/
/*                                   MAIN                                     */
                                    
int main() {
    char command;

    /* initializes the head and tail pointers
     for 1 linked list of lines and 1 of stops*/
    
    listItem *headLines = NULL;
    listItem *tailLines = NULL;
    listItem *headStops = NULL;
    listItem *tailStops = NULL;

     int freeDone = FALSE;
    command = getchar();

    while (command != 'q') {
        switch (command) {
        case 'c':
            AddListLines(&headLines, &tailLines);
            freeDone = FALSE;

            break;
        case 'p':
            AddListStops(&headStops, &tailStops);
            freeDone = FALSE; 

            break;
        case 'l':
            AddListLinks(&headLines, &headStops);
            freeDone = FALSE; 

            break;
        case 'i':
            Intersections(&headStops, &headLines);
            freeDone = FALSE; 

            break;
        case 'r':
            RemoveLine(&headLines, &headStops);
            freeDone = FALSE; 

            break;
           
        case 'e':
            EliminateStop(&headStops, &headLines);
             freeDone = FALSE; 

            break;
           
        case 'a':
            FreeMemory(&headLines, &headStops);
            headLines = NULL;
            tailLines = NULL;
            headStops = NULL;
            tailStops = NULL;
             freeDone = TRUE; 
            break;
        
        }
        command = getchar();
    }
    
    if (freeDone == FALSE) {
        FreeMemory(&headLines, &headStops);
    }
    
    return 0;
}