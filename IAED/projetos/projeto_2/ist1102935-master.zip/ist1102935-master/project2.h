 /* iaed-23 - ist1102935 - project2 */
/* HEADER file */

/* 
 * Author: Ines Garcia Cortes Cadete
 * Student Number: 102935
 * Course: IAED (2023)
*/
#ifndef DEFINITIONS_H
#define DEFINITIONS_H

#define MAX_INPUT 65535

/* return constants for checking */
#define TRUE 1
#define FALSE -1

/******************************************************************************/
/* structs for ListItems, Stops, Pointers to Stops and Lines */

typedef struct listItem {
    char *name;
	void *content;
	struct listItem *next;
    struct listItem *prev;
} listItem;


typedef struct stop {
    double lat;
    double longi;
    int numLines;
    double cost;
    double duration;
} stop;

typedef struct line {
    listItem *head; /* head of the linked list of pointers to stops */
    listItem *tail;
    int numStops;
    double totalCost;
    double totalDuration;

} line;

/******************************************************************************/
/* Prototypes */

/* lists.c */
void checkMemory(void *pointer);
char *strdup(const char *src);
listItem init();
listItem *ExistItem(char *name, listItem **headP);
listItem *AllocListItem();
line *AllocLine();
listItem *CreateLine(char name[]);
void FirstItemEver(listItem *item, listItem **headP, listItem **tailP);
void AddFirst(listItem *item, listItem **headP);
void AddLastItem(listItem *item, listItem **tailP);
void AddItem(listItem *item, listItem **headP, listItem **tailP, int first);
void ListLines(listItem **headLines);
void ListLineStops(listItem *line1, int notInv);
stop *AllocStop();
listItem *CreateStop(char *name, double lat, double longi);
listItem *CreateStopPointer(listItem *stop1);
void AddStopPointer(listItem *stop1, 
                    listItem **head, listItem **tail, int first);
void ListStops(listItem **headStops);
void UpdateLineCostDur(listItem *stop1, listItem *line1);
void ResetLineCostDurNumStops(listItem *line1);
void UpdateLine(listItem *line1, double cost, double duration);
void UpdateOriginStop(listItem *originStop, double cost, double duration);
void EmptyList(listItem **head);
listItem *ExtractFirstItem(listItem **headP);
listItem *ExtractNotFirstItem(listItem *item, listItem **tailP);
listItem *ExtractItem(listItem **head, listItem *item);
listItem *StopIsInLine(listItem *stop1, listItem *line1);
void ReduceNumLines(listItem *line1, listItem **headStops);
void FreeListItem(listItem *item);


/* main.c */
void AddListLines(listItem **headLines, listItem **tailLines);
void AddListStops(listItem **headStops, listItem **tailStops);
void ReadBetweenQuotes(char stopName[]);
void ReadWithoutQuotes(char stopName[], char c);
int NoErrors(double cost, double duration, listItem *line1,
             listItem *originStop, listItem *destStop, 
             char lineName[], char originStop1[], char destStop1[]);
void ApplyWhichLink(listItem *line1,
                    listItem *originStop, listItem *destStop, 
                    double cost, double duration);
void AddListLinks(listItem **headLines, listItem **headStops);
void InsertSortArray(char **array, int len);
void PrintIntersections(char *name, char **array, int len);
void Intersections(listItem **headStops, listItem **headLines);
void RemoveLine(listItem **headLines, listItem **headStops);
void EliminateStop(listItem **headStops, listItem **headLines);
void FreeMemory(listItem **headLines, listItem **headStops);

#endif
