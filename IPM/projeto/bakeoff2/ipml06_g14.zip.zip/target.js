


// Target class (position and width)
class Target
{  
  
  constructor(x, y, w, l, id, cor)
  {
    this.x      = x;
    this.y      = y;
    this.width  = w;
    this.label  = l;
    this.id     = id;
    this.cor = cor;
    this.hovered = false;
  }
  
  // Checks if a mouse click took place
  // within the target
  clicked(mouse_x, mouse_y)
  {
    return dist(this.x, this.y, mouse_x, mouse_y) < this.width / 2;
  }
  
  // Draws the target (i.e., a circle)
  // and its label
  draw()
  {
    ////////////////////////
       // Set drop shadow properties
    let shadowColor = color(0, 0, 0, 100); // Shadow color with transparency
    let shadowOffsetX = 1; // Horizontal offset of the shadow
    let shadowOffsetY = 1; // Vertical offset of the shadow
    let shadowBlur = 1; // Blur radius of the shadow

    
    // Apply drop shadow properties
    drawingContext.shadowColor = shadowColor;
    drawingContext.shadowBlur = shadowBlur;
    drawingContext.shadowOffsetX = shadowOffsetX;
    drawingContext.shadowOffsetY = shadowOffsetY;
    
    
        noStroke(); // No border for the shadow

    /////////////////////////////
    ///////MUDAR PARA O BORDER NAO FICAR CONFUSO/////
    /*if (["Bacolod", "Béchar", "Bhilai", "Byalystok", "Bochum", "Braga", "Bucharest"].includes(this.label)) {
        strokeWeight(4);
    } else {
        noStroke(); // Ensure no stroke is applied if label doesn't match
    }
    stroke(255); // Adjust the color of the border as needed
    ///////////////////////////////
    */
    // Draw target
    fill(this.cor); // AQUI                 
    //circle(this.x, this.y, this.width);
    
        rectMode(CENTER);
  
    rect(this.x, this.y, this.width + 25, 90, 20);
    
    // Reset shadow
    drawingContext.shadowColor = 'transparent'; // Reset shadow color
    drawingContext.shadowBlur = 0; // Reset shadow blur
    drawingContext.shadowOffsetX = 0; // Reset shadow offset X
    drawingContext.shadowOffsetY = 0; // Reset shadow offset Y

    
    
    // Draw label
    strokeWeight(0);
    fill(color(255,255,255));
    textAlign(CENTER);

    // Primeiras três letras em negrito
    let firstThreeLetters = this.label.substring(0, 3);
    let remainingText = this.label.substring(3);
    
      textFont("Arial", 28);
    
    textStyle(BOLD);
    fill(color(255, 255, 255, 190)); // Change 150 to the desired alpha value

    //fill(color(237, 237, 242));
    text(firstThreeLetters, this.x, this.y - 13); // Ajuste a posição vertical conforme necessário
    
        textFont("Arial", 18);

    fill(color(255, 255, 255));
    textStyle(BOLD);

    text(this.label, this.x, this.y + 15); // Ajuste a posição vertical conforme necessário
    
    //text(this.label, this.x, this.y);
  }
  /////////////////////////////////////////////////////
  hover(mx, my) {
    // Check if the mouse is hovering over the target
    let d = dist(mx, my, this.x, this.y);
    if (d < this.width / 2) {
      this.hovered = true;
      return true;
    } else {
      this.hovered = false;
      return false;
    }
  }

  highlight() {
    // Highlight all targets of the same color group when hovered
    if (this.hovered) {
      
      //////////////////MUDAR ESTA PARTE PARA DAR MAIS HIGHLIGHT NO HOVER/////
      let brighterColor1 = color(this.cor.levels[0] + 100, 
                                          this.cor.levels[1] + 140, 
                                          this.cor.levels[2] + 140);
                stroke(brighterColor1);
                strokeWeight(5); // Adjust border thickness as needed
                noFill(); // No fill for the border
                rect(this.x, this.y, this.width + 25, 90, 20); // Increase size for highlighting
      ///////////////////
      
      for (let j = 0; j < targets.length; j++) {
        if (this.cor.toString() === targets[j].cor.toString()) {
          /*stroke(255);
          strokeWeight(3);
          noFill();
          //ellipse(targets[j].x, targets[j].y, targets[j].width + 10); // Increase size for highlighting
          rect(targets[j].x, targets[j].y, targets[j].width + 10); // Increase size for highlighting
  */
        // Get the current color and make it brighter
                let brighterColor = color(targets[j].cor.levels[0] + 100, 
                                          targets[j].cor.levels[1] + 100, 
                                          targets[j].cor.levels[2] + 100);
                stroke(brighterColor);
                strokeWeight(5); // Adjust border thickness as needed
                noFill(); // No fill for the border
                rect(targets[j].x, targets[j].y, targets[j].width + 25, 90, 20); // Increase size for highlighting

            }
      }
  }
  }
  /////////////////////////////////////////////////////
  
  
}