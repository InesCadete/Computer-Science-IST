#include "L2Cache2Ways.h"

uint8_t L1Cache[L1_SIZE];
uint8_t L2Cache[L2_SIZE];
uint8_t DRAM[DRAM_SIZE];
uint32_t time;
CacheL1 SimpleCacheL1;
CacheL2 SimpleCacheL2;

/**************** Time Manipulation ***************/
void resetTime() { time = 0; }

uint32_t getTime() { return time; }

/****************  RAM memory (byte addressable) ***************/
void accessDRAM(uint32_t address, uint8_t *data, uint32_t mode) {

  if (address >= DRAM_SIZE - WORD_SIZE + 1)
    exit(-1);

  if (mode == MODE_READ) {
    memcpy(data, &(DRAM[address]), BLOCK_SIZE);
    time += DRAM_READ_TIME;
  }

  if (mode == MODE_WRITE) {
    memcpy(&(DRAM[address]), data, BLOCK_SIZE);
    time += DRAM_WRITE_TIME;
  }
}

/*********************** L1 cache *************************/

void initCache() { 
  int i, j;
  memset(SimpleCacheL1.line, 0, sizeof(SimpleCacheL1.line));
  memset(SimpleCacheL2.set, 0, sizeof(SimpleCacheL2.set));

  for (i = 0; i < CACHE_LINES; i++) {
    SimpleCacheL1.line[i].Valid = 0;
  } 
  for (i = 0; i < SET_NUMBER; i++) {
    for (j = 0; j < WAY_NUMBER; j++){
      SimpleCacheL2.set[i].line[j].Valid = 0;
      SimpleCacheL2.set[i].line[j].Time = 0;
    }
  } 
}

void accessL1(uint32_t address, uint8_t *data, uint32_t mode) {

  /*
   * 
   *  |   Tag        Index     Offset: blockAddr + byteAddr  |
   *  |__________|__________|________________________________|
   *
   *  Memmory address: Tag + blockAddr, byteAddr is not relevant
   *
   *  L1Cache address: Index + Offset
   *
   *  SimpleCache address: Index
   *
   * */


  uint8_t index, TempBlock[BLOCK_SIZE];
  uint16_t cacheAddr;
  uint32_t tag;

  tag = (address >> (ADDRESS_BITS - (OFFSET_BITS + INDEX_BITS))); // (Tag)
  index = (address >> 6) & ((1 << INDEX_BITS) - 1); // (Index) 
  cacheAddr = address & ((1 << (INDEX_BITS + OFFSET_BITS)) - 1); // (Index + Offset)

  CacheLine *Line = &SimpleCacheL1.line[index];

  /* access Cache*/

  if (!Line->Valid || Line->Tag != tag) {         // if block not present - miss
    accessL2(address, TempBlock, MODE_READ); // get new block from L2 Cache

    if ((Line->Valid) && (Line->Dirty)) { // line has dirty block
      accessL2(address, &(L1Cache[cacheAddr]), MODE_WRITE); // then write back old block
    }       

    memcpy(&(L1Cache[cacheAddr]), TempBlock,
           BLOCK_SIZE); // copy new block to cache line
    Line->Valid = 1;
    Line->Tag = tag;
    Line->Dirty = 0;
  } // if miss, then replaced with the correct block

  if (mode == MODE_READ) { // read data from cache line
    memcpy(data, &(L1Cache[cacheAddr]), WORD_SIZE);
    time += L1_READ_TIME;
  }

  if (mode == MODE_WRITE) { // write data into cache line
    memcpy(&(L1Cache[cacheAddr]), data, WORD_SIZE);
    time += L1_WRITE_TIME;
    Line->Dirty = 1;
  }
}

// Search for the Line in the Set
CacheLine *getSetLine(uint8_t setIndex, uint32_t tag, uint32_t mode) {
  int i;
  CacheLine *Line = NULL;
  uint32_t lruTime = SimpleCacheL2.set[setIndex].line[0].Time;

  for (i = 0; i < WAY_NUMBER; i++) {
    if (mode == MODE_READ) {
      if (SimpleCacheL2.set[setIndex].line[i].Valid &&
          SimpleCacheL2.set[setIndex].line[i].Tag == tag) {
        return &SimpleCacheL2.set[setIndex].line[i];
      }
    }
    if (mode == MODE_WRITE) {
      if (SimpleCacheL2.set[setIndex].line[i].Time < lruTime) {
        lruTime = SimpleCacheL2.set[setIndex].line[i].Time;  
        Line = &SimpleCacheL2.set[setIndex].line[i];
      }
    }
    if (!SimpleCacheL2.set[setIndex].line[i].Valid) {
      Line = &SimpleCacheL2.set[setIndex].line[i];
    }
  }
 
  return Line;
}

void accessL2(uint32_t address, uint8_t *data, uint32_t mode){
  uint8_t setIndex, blockAddr, TempBlock[BLOCK_SIZE];
  uint16_t cacheAddr;
  uint32_t tag, MemAddr;

  tag = (address >> (ADDRESS_BITS - (OFFSET_BITS + INDEX_BITS))); // (Tag)
  setIndex = (address >> 6) & ((1 << INDEX_BITS) - 1); // (Set Index) 
  blockAddr = (address >> BYTE_BITS) & ((1 << BLOCK_BITS) - 1); // (blockAddr)
  cacheAddr = address & ((1 << (INDEX_BITS + OFFSET_BITS)) - 1); // (Index + Offset)
  MemAddr = (tag << BLOCK_BITS) | blockAddr; // (Tag + blockAddr)

  CacheLine *Line = getSetLine(setIndex, tag, mode); 

  /* access Cache*/

  if (!Line->Valid || Line->Tag != tag) {         // if block not present - miss
    accessDRAM(MemAddr, TempBlock, MODE_READ); // get new block from DRAM

    if ((Line->Valid) && (Line->Dirty)) { // line has dirty block
      accessDRAM(MemAddr, &(L2Cache[cacheAddr]), MODE_WRITE); // then write back old block
    }

    memcpy(&(L2Cache[cacheAddr]), TempBlock, BLOCK_SIZE); // copy new block to cache line
    Line->Valid = 1;
    Line->Tag = tag;
    Line->Dirty = 0;
  } // if miss, then replaced with the correct block

  if (mode == MODE_READ) { // read data from cache line
    memcpy(data, &(L2Cache[cacheAddr]), WORD_SIZE);
    time += L2_READ_TIME;
  }

  if (mode == MODE_WRITE) { // write data into cache line
    memcpy(&(L2Cache[cacheAddr]), data, WORD_SIZE);
    time += L2_WRITE_TIME;
    Line->Dirty = 1;
  }
  Line->Time = getTime();
}

void read(uint32_t address, uint8_t *data) {
  accessL1(address, data, MODE_READ);
}

void write(uint32_t address, uint8_t *data) {
  accessL1(address, data, MODE_WRITE);
}
