#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include "L2Cache2Ways.h"

// ANSI color codes for output
#define COLOR_GREEN  "\x1B[32m"
#define COLOR_RED    "\x1B[31m"
#define COLOR_RESET  "\x1B[0m"

// Function to test cache initialization
void test_init_cache() {
    initCache();
}

// Function to test writing to the cache and checking for cache hit
void test_write() {
    uint8_t data = 0xAB; // Data to write
    uint32_t address = 0x1A2B; // Address to write to

    resetTime();

    printf("Writing data 0x%X to address 0x%X...\n", data, address);
    write(address, &data);

    uint32_t time = getTime();
    assert(time == 111);

    printf("Time taken: %ds (expected 111s) \n", time);
    printf("Data written successfully.\n");
}

// Function to test reading from the cache (check for hit)
void test_read_hit() {
    uint8_t data = 0;
    uint32_t address = 0x1A2B; 

    resetTime();

    printf("Reading data from address 0x%X...\n", address);
    read(address, &data);

    assert(data == 0xAB);

    uint32_t time = getTime();
    assert(time == 1);

    printf("Time taken: %ds (expected 1s) \n", time);
    printf("Data read from address 0x%X: 0x%X (expected 0xAB)\n", address, data);
}

void test_read_miss_with_eviction() {
    uint8_t data1 = 0xAB;
    uint8_t data2 = 0xCD;
    uint8_t data_read = 0;
    uint32_t address1 = 0x00000000; 
    uint32_t address2 = 0x00000004;

    resetTime();
    printf("Writing data 0x%X to address 0x%X (this will occupy a cache line)...\n", data1, address1);
    
    write(address1, &data1);
    assert(getTime() == 111);

    read(address1, &data_read);
    assert(getTime() == 112);

    assert(data_read == 0xAB);

    printf("Writing data 0x%X to address 0x%X (this will cause an eviction in the cache)...\n", data2, address2);
    write(address2, &data2);

    assert(getTime() == 113);

    read(address2, &data_read); 
    assert(getTime() == 114);
}

int main() {
    test_init_cache();

    test_write();
    printf(COLOR_GREEN "Write test passed successfully!\n" COLOR_RESET);
    test_read_hit();
    printf(COLOR_GREEN "Read hit test passed successfully!\n" COLOR_RESET);
    test_read_miss_with_eviction();
    printf(COLOR_GREEN "Read miss with eviction test passed successfully!\n" COLOR_RESET);
    
    printf(COLOR_GREEN "All tests passed successfully!\n" COLOR_RESET);
    return 0;
}
