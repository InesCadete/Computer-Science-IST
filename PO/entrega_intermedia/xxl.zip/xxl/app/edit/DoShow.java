package xxl.app.edit;

import pt.tecnico.uilib.menus.Command;

import pt.tecnico.uilib.menus.CommandException;
import xxl.app.edit.Message;
import xxl.core.Cell;
import xxl.core.Spreadsheet;

import java.util.Collections;
import java.util.List;

import xxl.core.Range;
// FIXME import classes

/**
 * Class for searching functions.
 */
public class DoShow extends Command<Spreadsheet> {

  DoShow(Spreadsheet receiver) {
    super(Label.SHOW, receiver);
    addStringField("address", Message.address());
  }

  @Override
  protected final void execute() throws CommandException {

    // parses the given string in the form
    String s = stringField("address");
    String[] rangeCoordinates = s.split("[:;]");
    int firstRow = Integer.parseInt(rangeCoordinates[0]);
    int firstColumn = Integer.parseInt(rangeCoordinates[1]);
    int lastRow = Integer.parseInt(rangeCoordinates[2]);
    int lastColumn = Integer.parseInt(rangeCoordinates[3]);

    Range r = new Range(firstRow, firstColumn, lastRow, lastColumn, _receiver);

    for (Cell cell : r.getCells()) {

      _display.addLine(cell.toString());
      _display.display();
    }
  }
}
