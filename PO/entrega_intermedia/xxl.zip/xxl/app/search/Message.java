package xxl.app.search;

/**
 * Messages.
 */
interface Message {
  static String searchValue() {
    return "Valor a procurar: ";
  }
  
  static String searchFunction() {
    return "Função a procurar: ";
  }
}
