package xxl.core;

public abstract class BinaryFunction extends Function {

    private Content _firstContent;
    private Content _secondContent;

    public BinaryFunction(String name, Content one, Content two) {
        super(name);
        _firstContent = one;
        _secondContent = two;
    }

    public Content getFirstContent() {
        return _firstContent;
    }

    public Content getSecondContent() {
        return _secondContent;
    }

    @Override
    public String toString() {
        //Retract '=' if it's a reference
        String content1 = this.getFirstContent().toString();
        if (content1.charAt(0) =='=') {
            content1 = content1.substring(1);
        }

        String content2 = this.getSecondContent().toString();
        if (content2.charAt(0) =='=') {
            content2 = content2.substring(1);
        }
        return this.value().toString() + "=" + getName() + "(" +content1 + "," + content2 + ")";
    }


}
