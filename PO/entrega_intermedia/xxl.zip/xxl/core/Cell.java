package xxl.core;

public class Cell {
    
    private int _row;
    private int _column;
    private Content _content;

    public int getRow() {
        return _row;
    }

    public Content getContent() {
        return _content;
    }

    public int getColumn() {
        return _column;
    }

    public Cell(int row, int column) {
        _row = row;
        _column = column;
    }

    void setContent(Content content) {
        _content = content;
    }



    Literal value() {
        if (_content==null){
            return null;
        }
        return _content.value();
    }

    public boolean emptyCell(int row, int column, Spreadsheet spreadsheet){
        return ((spreadsheet.getCell(row, column)._content)==null);
    }

    @Override
    public String toString() {
        if(_content == null)
            return _row+";"+_column+"|";
        else
            return _row+";"+_column+"|"+_content.toString();
    }
}
