package xxl.core;

import xxl.core.exception.IntegerNotStringException;
import xxl.core.exception.StringNotIntegerException;

public class Coalesce extends IntervalFunction{

    public Coalesce(int beginRow, int beginColumn, int endRow, int endColumn,
                  Spreadsheet spreadsheet) {

        super(beginRow, beginColumn, endRow, endColumn, "COALESCE", spreadsheet);
    }

    protected Literal compute(){
        for(Cell c : this.getRange().getCells()) {
            try {
                if (!(c.getContent()==null)){
                    c.value().asInt();
                }

            }
            catch(StringNotIntegerException e) {
                return c.value();
            }
        }
        return new LiteralString("");
    }
}


