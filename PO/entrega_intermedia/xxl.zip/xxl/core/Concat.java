package xxl.core;

import xxl.core.exception.IntegerNotStringException;

public class Concat extends IntervalFunction {

    public Concat(int beginRow, int beginColumn, int endRow, int endColumn,
                  Spreadsheet spreadsheet) {

        super(beginRow, beginColumn, endRow, endColumn, "CONCAT", spreadsheet);
    }
    protected Literal compute(){;

        String aux ="";

        for(Cell c : this.getRange().getCells()) {
            try {
               aux = aux.concat(c.value().asString());
            }
            catch(IntegerNotStringException | NullPointerException e) {
                return new LiteralString("#VALUE");
            }
        }
        return new LiteralString(aux);
    }
}
