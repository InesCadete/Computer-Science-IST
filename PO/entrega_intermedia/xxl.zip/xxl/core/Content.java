package xxl.core;

import xxl.core.exception.IntegerNotStringException;
import xxl.core.exception.StringNotIntegerException;

// Tenho algumas dúvidas nesta implementação
// Perguntar pq os metodos asInt() e asString() não são abstratos ?

public abstract class Content {

    public abstract String toString();

    abstract Literal value();

    public String asString() throws IntegerNotStringException {
        return this.asString();
    }

    public int asInt() throws StringNotIntegerException {
        return this.asInt();
    }
}
