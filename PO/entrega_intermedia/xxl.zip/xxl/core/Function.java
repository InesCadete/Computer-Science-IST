package xxl.core;

import xxl.core.exception.IntegerNotStringException;
import xxl.core.exception.StringNotIntegerException;

public abstract class Function extends Content {

    private String _name;
    private Literal _value;

    public Function(String name) {
        _name = name;
        _value = compute();
    }

    public String getName() {
        return _name;
    }

    protected abstract Literal compute();

    public String asString() throws IntegerNotStringException {
        return _value.asString();
    }

    public int asInt() throws StringNotIntegerException {
        return _value.asInt();
    }

    public Literal value() {
        return _value;
    }

    protected void setValue(Literal v) {
        _value = v;
    }
}

