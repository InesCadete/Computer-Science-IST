package xxl.core;

public abstract class IntervalFunction extends Function {

    private Range _range;

    public IntervalFunction(int beginRow, int beginColumn, int endRow, int endColumn,
                            String name, Spreadsheet spreadsheet) {
            super(name);
            _range = new Range(beginRow, beginColumn, endRow, endColumn, spreadsheet);
    }

    public Range getRange(){
        return _range;
    }

    @Override
    public String toString(){
        return this.value().toString()+"="+getName()+ "("+this.getRange().getBeginRow()+
                ";"+this.getRange().getBeginColumn()+":"+this.getRange().getEndRow()+";"+getRange().getEndColumn()+")";
    }
}
