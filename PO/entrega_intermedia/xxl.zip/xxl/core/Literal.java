package xxl.core;

public abstract class Literal extends Content {
    
    Literal value() {
        return this;
    }
}
