package xxl.core;

import xxl.core.exception.IntegerNotStringException;

public class LiteralInteger extends Literal {

    private int _value;

    public LiteralInteger() {
        _value = 0;
    }

    public LiteralInteger(int value) {
        _value = value;
    }

    public String toString() {
        return Integer.toString(_value);
    }

    public String asString() throws IntegerNotStringException {
        throw new IntegerNotStringException();
    }

    public int asInt() {
        return _value;
    }

    public void setValue(int v) {
        _value = v;
    }

}
