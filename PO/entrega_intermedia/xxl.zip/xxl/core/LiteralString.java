package xxl.core;

import xxl.core.exception.StringNotIntegerException;

public class LiteralString extends Literal {

    private String _value;

    public LiteralString(String value) {
        _value = value;
    }

    public String toString() {
        return _value;
    }

    public String asString() {
        return _value;
    }

    public int asInt() throws StringNotIntegerException {
        throw new StringNotIntegerException();
    }            
}
