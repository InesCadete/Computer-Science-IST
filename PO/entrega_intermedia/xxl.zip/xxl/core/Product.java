package xxl.core;

import xxl.core.exception.IntegerNotStringException;
import xxl.core.exception.StringNotIntegerException;

public class Product extends IntervalFunction {

    public Product(int beginRow, int beginColumn, int endRow, int endColumn,
                  Spreadsheet spreadsheet) {

        super(beginRow, beginColumn, endRow, endColumn, "PRODUCT", spreadsheet);
    }
    protected Literal compute(){;

        int aux = 1;

        for(Cell c : this.getRange().getCells()) {
            try {
                aux *= (c.value().asInt());
            }
            catch(StringNotIntegerException | NullPointerException e) {
                return new LiteralString("#VALUE");
            }
        }
        return new LiteralInteger(aux);
    }
}



