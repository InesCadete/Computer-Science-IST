package xxl.core;

import java.util.*;

public class Range {
    private int _beginRow;
    private int _beginColumn;
    private int _endRow;
    private int _endColumn;

    private boolean _horizontal;

    private Spreadsheet _spreadsheet;

    public Range(int beginRow, int beginColumn, int endRow, int endColumn, Spreadsheet spreadsheet) {
        _beginRow = beginRow;
        _beginColumn = beginColumn;
        _endRow = endRow;
        _endColumn = endColumn;
        _spreadsheet = spreadsheet;
        if (beginRow == endRow)
                _horizontal = true;
    }

    public int getBeginRow() {
        return _beginRow;
    }

    public int getBeginColumn() {
        return _beginColumn;
    }

    public int getEndRow() {
        return _endRow;
    }

    public int getEndColumn() {
        return _endColumn;
    }

    public Spreadsheet getSpreadsheet() {
        return _spreadsheet;
    }

    public List<Cell> getCells() {
        List<Cell> aux = new ArrayList<>();
        if (_horizontal){
            for(int column = _beginColumn; column <= _endColumn; column++) {
                aux.add(_spreadsheet.getCell(_beginRow, column));
            }
        }
        else {
            for(int row = _beginRow; row <= _endRow; row++) {
                aux.add(_spreadsheet.getCell(row, _beginColumn));
            }
        }
        return Collections.unmodifiableList(aux);
    }
}
