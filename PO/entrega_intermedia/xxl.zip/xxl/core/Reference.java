package xxl.core;

public class Reference extends Content {

    private int _row;
    private int _column;

   private Spreadsheet _spreadsheet;

    public Reference(int row, int column) {
        _row = row;
        _column = column;
    }

    public int getRow() {
        return _row;
    }

    public int getColumn(){
        return _column;
    }

    public String toString(){

        return "="+Integer.toString(_row)+";"+Integer.toString(_column);
    }

    
    Literal value() {
        return _spreadsheet.getCell(_row, _column).value();
    }
}
