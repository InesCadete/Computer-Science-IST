package xxl.core;

// FIXME import classes
import java.io.SerializablePermission;
import java.util.*;
import java.io.Serial;
import java.io.Serializable;

import xxl.core.exception.ImportFileException;
import xxl.core.exception.UnrecognizedEntryException;
import xxl.core.exception.DimensionsOutOfBoundsException;

/**
 * Class representing a spreadsheet.
 */
public class Spreadsheet implements Serializable {
  @Serial
  private static final long serialVersionUID = 202308312359L;
  
  // FIXME define attributes
    private int _rows;
    private int _columns;

    private boolean _changed;
    private HashSet<User> _users;
    private ArrayList<ArrayList<Cell>> _matrix;

  // FIXME define contructor(s)

    public Spreadsheet(int rows, int columns) {
      
      _rows = rows;
      _columns = columns;
      _changed = false;

      _users = new HashSet<>();
      _matrix = new ArrayList<>();

      for (int i = 0; i < rows; i ++) {
        ArrayList<Cell> row = new ArrayList<>();
        for (int j = 0; j < columns; j++) {
          row.add(new Cell(i+1, j+1));
        }
        _matrix.add(row);
      }

    }

  public Boolean getChanged() {
      return _changed;
  }

  public void setChanged(Boolean bool) { _changed = bool;};
  public int getRows() {
      return _rows;
  }
  
  public int getColumns() {
      return _columns;
  }

  public Cell getCell(int row, int column) {

    int rowIndex = row-1;
    int columnIndex = column-1;

    return _matrix.get(rowIndex).get(columnIndex);
    
  }

  public void addUser(User u) {
    _users.add(u);
  }
  
  /**
   * Insert specified content in specified address.
   *
   * @param row the row of the cell to change 
   * @param column the column of the cell to change
   * @param contentSpecification the specification in a string format of the content to put
   *        in the specified cell.
   */
  public void insertContent(int row, int column, Content contentSpecification) throws UnrecognizedEntryException /* FIXME maybe add exceptions */ {
    //FIXME implement method
    this.getCell(row, column).setContent(contentSpecification);

  }

  public Range createRange(String range) throws UnrecognizedEntryException, DimensionsOutOfBoundsException {
    String[] rangeCoordinates;
    int firstRow, firstColumn, lastRow, lastColumn;

    if (range.indexOf(':') != -1) {
      rangeCoordinates = range.split("[:;]");
      firstRow = Integer.parseInt(rangeCoordinates[0]);
      firstColumn = Integer.parseInt(rangeCoordinates[1]);
      lastRow = Integer.parseInt(rangeCoordinates[2]);
      lastColumn = Integer.parseInt(rangeCoordinates[3]);
    } else {
      rangeCoordinates = range.split(";");
      firstRow = lastRow = Integer.parseInt(rangeCoordinates[0]);
      firstColumn = lastColumn = Integer.parseInt(rangeCoordinates[1]);
    }

    if (!checkCoordinates(firstRow, firstColumn, lastRow, lastColumn)) {
      throw new DimensionsOutOfBoundsException();
    }
      return new Range(firstRow, firstColumn, lastRow, lastColumn, this);
  }

  public boolean checkCoordinates(int firstRow, int firstColumn, int lastRow, int lastColumn) {

      return ((!(firstRow >= 0 && lastRow < this.getRows() && firstRow <= lastRow))) ||
      (!(firstColumn >= 0 && lastColumn < this.getColumns() && firstColumn <= lastColumn));
  }
}