package xxl.core;

import xxl.core.exception.StringNotIntegerException;

public class Sub extends BinaryFunction {

    public Sub(Content one, Content two) {
        super("SUB", one, two);
    }

    protected Literal compute() {

        LiteralInteger result = new LiteralInteger();

        try {
            int r = getFirstContent().value().asInt() - getSecondContent().value().asInt();
            result.setValue(r);
        } catch (StringNotIntegerException | NullPointerException e) {
            LiteralString resultFail = new LiteralString("#VALUE");
            this.setValue(resultFail);
            return resultFail;
        }
        this.setValue(result);
        return result;
    }
}
