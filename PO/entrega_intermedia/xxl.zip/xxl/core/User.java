package xxl.core;

import java.util.*;

public class User {

    private String _name;
    private ArrayList<Spreadsheet> _spreadsheets;

    public User(String name) {
        _name = name;
        _spreadsheets = new ArrayList<Spreadsheet>();
    }

    public String getName() {
        return _name;
    }

    public void setName(String name) {
        _name = name;
    }

    void add(Spreadsheet sheet) {
        _spreadsheets.add(sheet);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        User user = (User) o;
        return Objects.equals(_name, user._name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(_name);
    }

    
}
