package xxl.core.exception;


public class DimensionsOutOfBoundsException extends Exception { }
