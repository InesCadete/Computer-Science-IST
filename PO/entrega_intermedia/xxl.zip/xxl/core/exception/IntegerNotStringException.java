package xxl.core.exception;

public class IntegerNotStringException extends Exception {

    private static final String ERROR_MESSAGE = "O conteudo desta Célula é um Inteiro e não uma String ";

    public IntegerNotStringException() {
        super(ERROR_MESSAGE);
    }
}
