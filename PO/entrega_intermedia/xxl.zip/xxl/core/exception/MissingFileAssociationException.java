package xxl.core.exception;

/**
 * Thrown when an application is not associated with a file.i
 */
public class MissingFileAssociationException extends Exception {
}
