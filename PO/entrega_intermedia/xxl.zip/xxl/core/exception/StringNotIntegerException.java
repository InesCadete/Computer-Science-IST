package xxl.core.exception;

public class StringNotIntegerException extends Exception {

    private static final String ERROR_MESSAGE = "O conteudo desta Célula é uma String e não um Inteiro ";
    
    public StringNotIntegerException() {
        super(ERROR_MESSAGE);
    }
}



